# 📁 We Can Payment Tracker - Project Structure

## Complete File Organization

```
we-can-payment-tracker/
│
├── 📄 Configuration Files
│   ├── package.json              # Dependencies and scripts
│   ├── tsconfig.json             # TypeScript configuration
│   ├── next.config.js            # Next.js settings
│   ├── tailwind.config.js         # Tailwind CSS theme
│   ├── postcss.config.js          # PostCSS plugins
│   ├── vercel.json               # Vercel deployment config
│   └── .gitignore                # Git ignore rules
│
├── 📋 Environment & Documentation
│   ├── .env.example              # Example env variables
│   ├── README.md                 # Full documentation
│   ├── QUICKSTART.md             # 15-minute setup guide
│   └── PROJECT_STRUCTURE.md      # This file
│
├── 📂 src/ - Source Code
│   │
│   ├── app/                      # Next.js App Router
│   │   ├── layout.tsx            # Root layout
│   │   ├── page.tsx              # Home page (Member/Admin selector)
│   │   │
│   │   ├── user/                 # Member routes
│   │   │   ├── login/
│   │   │   │   └── page.tsx      # Phone number login
│   │   │   ├── register/
│   │   │   │   └── page.tsx      # New member registration
│   │   │   └── dashboard/
│   │   │       └── page.tsx      # Member payment dashboard
│   │   │
│   │   └── admin/                # Admin routes
│   │       ├── login/
│   │       │   └── page.tsx      # Password login
│   │       ├── dashboard/
│   │       │   └── page.tsx      # Admin overview
│   │       └── member/
│   │           └── [id]/
│   │               └── page.tsx  # Edit member payments
│   │
│   ├── components/               # Reusable components
│   │   └── PaymentStatusBadge.tsx # Status indicator component
│   │
│   ├── lib/                      # Utilities & API
│   │   └── supabaseClient.ts     # Supabase setup & queries
│   │
│   └── styles/                   # Global styles
│       └── globals.css           # Tailwind & custom CSS
│
├── 📂 supabase/                  # Database migrations
│   └── migrations/
│       └── 001_init_schema.sql   # Database schema & seed data
│
├── 📂 public/                    # Static files (create if needed)
│
└── node_modules/                # Dependencies (after npm install)
```

---

## Key Files Explained

### Core Application Files

| File | Purpose |
|------|---------|
| `src/app/page.tsx` | Home page - choose Member or Admin |
| `src/app/user/dashboard/page.tsx` | Member's payment status view |
| `src/app/admin/dashboard/page.tsx` | Admin overview of all families |
| `src/lib/supabaseClient.ts` | All database connections & queries |
| `tailwind.config.js` | Colors, spacing, responsive breakpoints |

### Configuration Files

| File | Purpose |
|------|---------|
| `package.json` | Dependencies (React, Next.js, Supabase, Tailwind) |
| `tsconfig.json` | TypeScript rules & path aliases |
| `next.config.js` | Next.js build & runtime settings |
| `.env.example` | Template for environment variables |

### Documentation

| File | Purpose |
|------|---------|
| `README.md` | Complete setup & feature documentation |
| `QUICKSTART.md` | 15-minute quick start |
| `PROJECT_STRUCTURE.md` | This file - architecture overview |

---

## Database Schema

### Groups Table
```sql
- id (UUID, primary key)
- name (text) - e.g., "Warriors Family"
- created_at (timestamp)
```

### Members Table
```sql
- id (UUID, primary key)
- name (text) - Full name
- gender (text) - Male/Female
- phone (text) - Unique phone number
- group_id (UUID) - Foreign key to groups
- registered_at (timestamp)
- updated_at (timestamp)
```

### Payments Table
```sql
- id (UUID, primary key)
- member_id (UUID) - Foreign key to members
- month (int) - 1-12
- year (int) - 2024, 2025, etc.
- status (text) - 'paid' | 'pending' | 'unpaid'
- amount (int) - In RWF (default: 1000)
- marked_at (timestamp)
- notes (text) - Optional notes
```

---

## Component Hierarchy

```
App (Root Layout)
├── Home Page
│   ├── Member Card → User/Login
│   └── Admin Card → Admin/Login
│
├── User Routes
│   ├── User/Login
│   │   └── Phone Number Input
│   ├── User/Register
│   │   ├── Name Input
│   │   ├── Gender Select
│   │   ├── Phone Input
│   │   └── Group Select
│   └── User/Dashboard
│       ├── Header
│       ├── Statistics Cards
│       ├── PaymentStatusBadge (×12)
│       └── Info Message
│
└── Admin Routes
    ├── Admin/Login
    │   └── Password Input
    ├── Admin/Dashboard
    │   ├── Header
    │   ├── Group Selector
    │   ├── Statistics
    │   ├── All Families Table
    │   └── Members Table
    └── Admin/Member/[id]
        ├── Member Info
        ├── Payment Grid (×12)
        └── Delete Button
```

---

## API Endpoints (Supabase)

### Queries (Read)
- `fetchGroups()` - Get all family groups
- `fetchMemberByPhone(phone)` - Find member by phone
- `fetchMemberPayments(memberId)` - Get member's payment history
- `fetchAllPayments(month, year)` - Get all payments for a month
- `fetchMembersWithGroup(groupId)` - Get members in a family

### Mutations (Write)
- `registerMember()` - Create new member
- `updatePaymentStatus()` - Update payment (admin only)
- `upsertPayment()` - Create or update payment
- `deleteMember()` - Delete member (admin only)

---

## Environment Variables

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
NEXT_PUBLIC_ADMIN_PASSWORD=your-secure-password
NEXT_PUBLIC_APP_NAME=We Can Payment Tracker
NEXT_PUBLIC_CURRENCY=RWF
NEXT_PUBLIC_MINIMUM_AMOUNT=1000
```

---

## Routing Map

```
/ 
├── /user/login
├── /user/register
├── /user/dashboard

└── /admin/login
    ├── /admin/dashboard
    └── /admin/member/[id]
```

---

## Build & Deployment

### Local Development
```bash
npm install
npm run dev          # Runs on localhost:3000
```

### Production Build
```bash
npm run build        # Creates optimized build
npm start            # Runs production server
```

### Deployment Platforms
- **Vercel:** Recommended (GitHub integration, automatic deploys)
- **AWS Amplify:** Alternative option
- **Netlify:** Alternative option (needs serverless functions)

---

## Technology Choices Explained

| Technology | Why? |
|------------|------|
| **Next.js 14** | Modern, optimized, built-in API routes |
| **React 18** | Component-based UI, hooks support |
| **Supabase** | Open-source Firebase alternative, PostgreSQL |
| **Tailwind CSS** | Utility-first, responsive design, mobile-first |
| **TypeScript** | Type safety, better developer experience |
| **Vercel** | Made by Next.js creators, seamless integration |

---

## Performance Features

✅ **Code Splitting** - Each route loads only needed code  
✅ **Image Optimization** - Automatic image compression  
✅ **API Caching** - Supabase real-time subscriptions  
✅ **Mobile Optimization** - Responsive Tailwind CSS  
✅ **SEO Ready** - Next.js automatic metadata  

---

## Security Features

✅ **Row Level Security (RLS)** - Supabase policies  
✅ **Admin Password** - Protected control panel  
✅ **Environment Variables** - Secrets not in code  
✅ **HTTPS Only** - Vercel enforces SSL  
✅ **SQL Injection Protection** - Parameterized queries  

---

## Future Extension Points

### Easy to Add:
- Email notifications (Resend, SendGrid)
- SMS reminders (Twilio)
- Payment gateway (Stripe, Flutterwave)
- Advanced reports (Chart.js)
- Export to Excel (SheetJS)
- Authentication (Supabase Auth)

### File to Modify:
- Add new pages in `src/app/`
- New components in `src/components/`
- Database queries in `src/lib/supabaseClient.ts`
- Styling in `tailwind.config.js`

---

## Troubleshooting File Locations

| Issue | Check File |
|-------|------------|
| Build errors | `tsconfig.json`, `next.config.js` |
| Database issues | `supabase/migrations/001_init_schema.sql` |
| Styling problems | `src/styles/globals.css`, `tailwind.config.js` |
| API errors | `src/lib/supabaseClient.ts` |
| Route issues | `src/app/` folder structure |

---

**Last Updated:** 2024  
**Version:** 1.0.0  
**Status:** Production Ready ✅
