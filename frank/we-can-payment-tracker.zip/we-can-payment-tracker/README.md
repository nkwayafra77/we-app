# We Can Payment Tracker

A modern web application for tracking family group payment contributions. Built with **Next.js**, **React**, **Tailwind CSS**, and **Supabase**.

## Features

✅ **Member Registration** - Phone-based signup without authentication  
✅ **Payment Tracking** - Monthly payment status for members (Paid/Pending/Not Paid)  
✅ **User Dashboard** - View personal payment history and status  
✅ **Admin Panel** - Password-protected management console  
✅ **Family Groups** - Track 10 pre-configured family groups  
✅ **Responsive Design** - Works seamlessly on mobile and desktop  
✅ **Real-time Updates** - Live data with Supabase  
✅ **Email Notifications** - Ready for future email integration  

---

## Tech Stack

- **Frontend:** Next.js 14, React 18, Tailwind CSS
- **Backend:** Supabase (PostgreSQL)
- **Deployment:** Vercel
- **Icons:** Lucide React
- **Package Manager:** npm

---

## Prerequisites

Before you begin, you need:

1. **Node.js** (v16 or higher) - [Download](https://nodejs.org)
2. **npm** or **yarn**
3. **Supabase Account** - [Sign up free](https://supabase.com)
4. **Vercel Account** - [Sign up free](https://vercel.com)
5. **Git** (optional but recommended)

---

## Setup Instructions

### 1. Clone or Download the Project

```bash
git clone <your-repo-url>
cd we-can-payment-tracker
```

Or download the ZIP file and extract it.

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up Supabase

#### A. Create a Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign up
2. Click "New Project"
3. Choose your organization and enter a project name
4. Set a strong password
5. Choose a region (closest to you)
6. Click "Create new project" and wait for it to initialize

#### B. Create Tables and Run Migration

1. In Supabase, go to **SQL Editor**
2. Click **New Query**
3. Copy the entire contents of `supabase/migrations/001_init_schema.sql`
4. Paste it into the query editor
5. Click **Run** (▶️)
6. Wait for completion (you should see green checkmarks)

#### C. Get Your API Keys

1. Go to **Project Settings** → **API**
2. Copy:
   - **Project URL** (looks like: `https://xxxx.supabase.co`)
   - **anon public key** (looks like: `eyJhbGc...`)
3. Save these for the next step

### 4. Configure Environment Variables

1. Create a file named `.env.local` in the project root:

```bash
cp .env.example .env.local
```

2. Edit `.env.local` and fill in:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-url.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
NEXT_PUBLIC_ADMIN_PASSWORD=your-secure-password-here
NEXT_PUBLIC_APP_NAME=We Can Payment Tracker
NEXT_PUBLIC_CURRENCY=RWF
NEXT_PUBLIC_MINIMUM_AMOUNT=1000
```

Replace the values with your actual Supabase credentials and choose a strong admin password.

### 5. Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

You should see the home page with "Member" and "Admin" options.

### 6. Test the App

**As a Member:**
1. Click "Member"
2. Click "Don't have an account? Register here"
3. Fill in the registration form:
   - Name: Your full name
   - Gender: Male/Female
   - Phone: `0788123456` (any 10 digits)
   - Family: Choose any family
4. You'll be redirected to your dashboard

**As Admin:**
1. Click "Admin" on the home page
2. Enter your admin password (from `.env.local`)
3. You'll see the admin dashboard with all families and members

---

## Deployment to Vercel

### Step 1: Push to GitHub (Required)

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/we-can-payment-tracker.git
git push -u origin main
```

### Step 2: Deploy on Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Click "Import Git Repository"
4. Paste your GitHub repo URL and click "Continue"
5. Select the root directory (leave as default)
6. Click "Continue"

### Step 3: Set Environment Variables

1. In the Environment Variables section, add:

| Key | Value |
|-----|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your Supabase anon key |
| `NEXT_PUBLIC_ADMIN_PASSWORD` | Your chosen admin password |

2. Click "Deploy"

3. Wait for the deployment to complete (2-5 minutes)

4. You'll get a live URL like: `https://we-can-payment-tracker.vercel.app`

---

## Architecture Overview

### Pages Structure

```
src/app/
├── page.tsx                    # Home (Member/Admin selector)
├── user/
│   ├── login/page.tsx         # Phone number login
│   ├── register/page.tsx       # New member registration
│   └── dashboard/page.tsx      # Member's payment status
├── admin/
│   ├── login/page.tsx         # Admin password login
│   ├── dashboard/page.tsx      # Admin overview & management
│   └── member/[id]/page.tsx   # Edit member payments & delete
└── layout.tsx                  # Root layout
```

### Database Schema

**Groups Table**
- 10 pre-seeded families
- Used for member grouping

**Members Table**
- Phone, name, gender
- One member per phone number
- Links to a group

**Payments Table**
- Month + Year + Member combo
- Status: paid | pending | unpaid
- Amount: 1000 RWF (fixed)

---

## Features Explained

### 👤 Member Features

- **Register** with phone number (no email needed)
- **Login** with phone number only
- **View** payment history for last 12 months
- **See** status indicators with color coding:
  - 🟢 **Paid** (Green)
  - 🟡 **Pending** (Yellow)
  - 🔴 **Not Paid** (Red)

### 🔐 Admin Features

- **Password-protected** login (secure access)
- **View all families** and their payment statistics
- **Select a family** to see detailed member info
- **Edit payment status** for any month
- **Delete members** (permanent)
- **View progress** bars showing collection rates

---

## Default Families

The app comes with 10 families pre-configured:

1. Gentle Giants Family
2. Kind Souls Family
3. Little Lights Family
4. Golden Hearts Family
5. Faith Walkers Family
6. Warriors Family
7. Victorious Family
8. Tigers Family
9. Anointed Family
10. Solidarity Family

To add more families, edit `supabase/migrations/001_init_schema.sql` and re-run the migration.

---

## Color Coding

| Status | Color | Meaning |
|--------|-------|---------|
| **Paid** | 🟢 Green | Payment received |
| **Pending** | 🟡 Yellow | Payment awaited |
| **Not Paid** | 🔴 Red | No payment yet |

---

## Mobile Responsiveness

The app is fully responsive:

- **Mobile (< 640px):** Single column, optimized touch targets
- **Tablet (640px - 1024px):** 2-column grid
- **Desktop (> 1024px):** Full multi-column layout

---

## Security Notes

⚠️ **Important:**

1. **Password is Client-Side:** The admin password is checked in the browser for MVP. For production, implement server-side authentication.
2. **RLS Policies:** Supabase Row Level Security is enabled but limited (no auth users). Add Supabase Auth for proper security.
3. **Change Default Password:** Always change the admin password from the example.
4. **Keep Keys Private:** Never commit `.env.local` or expose your Supabase keys publicly.

---

## Troubleshooting

### Issue: "Cannot connect to Supabase"

**Solution:**
- Check `.env.local` has correct Supabase URL and key
- Ensure Supabase project is active (not paused)
- Verify firewall/VPN isn't blocking connections

### Issue: "Members table not found"

**Solution:**
- Run the SQL migration again in Supabase SQL Editor
- Check the migration ran successfully (look for green checkmarks)

### Issue: "Admin login doesn't work"

**Solution:**
- Verify `NEXT_PUBLIC_ADMIN_PASSWORD` in `.env.local`
- Restart the dev server: `npm run dev`

### Issue: "Deployment fails on Vercel"

**Solution:**
- Check build logs in Vercel dashboard
- Ensure all environment variables are set in Vercel project settings
- Verify `package.json` has correct scripts

---

## Future Enhancements

- 📧 Email notifications for payment reminders
- 💳 Payment gateway integration (Stripe, Flutterwave)
- 📊 Advanced reporting and analytics
- 🔐 Proper authentication with Supabase Auth
- 📱 Progressive Web App (PWA) support
- 🌐 Multi-language support

---

## Support

For issues or questions:

1. Check the [Troubleshooting](#troubleshooting) section
2. Review [Supabase Docs](https://supabase.com/docs)
3. Check [Next.js Docs](https://nextjs.org/docs)

---

## License

This project is open source and available under the MIT License.

---

## Quick Reference

### Common Commands

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Check for lint errors
npm run lint
```

### Environment Variables Reference

```
NEXT_PUBLIC_SUPABASE_URL=          # Supabase project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=     # Supabase anonymous key
NEXT_PUBLIC_ADMIN_PASSWORD=        # Admin panel password
NEXT_PUBLIC_APP_NAME=              # App title (default: We Can Payment Tracker)
NEXT_PUBLIC_CURRENCY=              # Currency code (default: RWF)
NEXT_PUBLIC_MINIMUM_AMOUNT=        # Min payment amount (default: 1000)
```

---

## Version History

**v1.0.0** - Initial release
- Member registration & login
- Payment status tracking
- Admin dashboard
- Vercel deployment ready

---

**Made with ❤️ for family groups and community organizations**
