# ✅ Deployment Checklist - We Can Payment Tracker

Follow this checklist to ensure smooth deployment to Vercel.

---

## Phase 1: Local Setup (15 minutes)

- [ ] **Install Node.js v16+**
  - Download from nodejs.org
  - Verify: `node --version` and `npm --version`

- [ ] **Create Supabase Project**
  - Go to supabase.com → Sign up
  - Create new project
  - Wait for initialization (2-3 minutes)

- [ ] **Create Database Tables**
  - Go to Supabase → SQL Editor
  - Copy from `supabase/migrations/001_init_schema.sql`
  - Run the SQL
  - Verify all 3 tables created ✅

- [ ] **Get Supabase Credentials**
  - Project Settings → API
  - Copy Project URL
  - Copy anon public key

- [ ] **Create `.env.local`**
  ```bash
  cp .env.example .env.local
  ```
  - Edit with your Supabase URL
  - Edit with your Supabase key
  - Set admin password

- [ ] **Install Dependencies**
  ```bash
  npm install
  ```

- [ ] **Run Locally**
  ```bash
  npm run dev
  ```
  - Open http://localhost:3000
  - Test member registration
  - Test admin login

---

## Phase 2: Git Setup (5 minutes)

- [ ] **Initialize Git Repository**
  ```bash
  git init
  git add .
  git commit -m "Initial commit: We Can Payment Tracker"
  ```

- [ ] **Create GitHub Account**
  - Go to github.com
  - Sign up if not already registered

- [ ] **Create GitHub Repository**
  - Click "New" on GitHub
  - Name: `we-can-payment-tracker`
  - Description: "Family groups payment tracker"
  - Public or Private (your choice)
  - Click "Create repository"

- [ ] **Link Local Repository to GitHub**
  ```bash
  git remote add origin https://github.com/YOUR-USERNAME/we-can-payment-tracker.git
  git branch -M main
  git push -u origin main
  ```

- [ ] **Verify on GitHub**
  - Go to your GitHub repo URL
  - Confirm all files are uploaded ✅

---

## Phase 3: Vercel Deployment (5 minutes)

- [ ] **Create Vercel Account**
  - Go to vercel.com
  - Sign up (can use GitHub account)

- [ ] **Create New Project**
  - Dashboard → Add New → Project
  - Import from Git
  - Select your GitHub repository

- [ ] **Configure Project**
  - Framework Preset: **Next.js**
  - Root Directory: **.** (leave as default)
  - Build Command: `npm run build` (auto-detected)

- [ ] **Add Environment Variables**
  In the "Environment Variables" section, add:
  
  | Key | Value |
  |-----|-------|
  | `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase URL |
  | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your Supabase anon key |
  | `NEXT_PUBLIC_ADMIN_PASSWORD` | Your admin password |
  | `NEXT_PUBLIC_APP_NAME` | We Can Payment Tracker |
  | `NEXT_PUBLIC_CURRENCY` | RWF |
  | `NEXT_PUBLIC_MINIMUM_AMOUNT` | 1000 |

- [ ] **Deploy**
  - Click "Deploy"
  - Wait for build completion (2-5 minutes)
  - See "Congratulations" message ✅

- [ ] **Get Your Live URL**
  - Copy the domain (e.g., we-can-payment-tracker.vercel.app)
  - Test the live app

---

## Phase 4: Post-Deployment Testing (10 minutes)

- [ ] **Test Member Features**
  - [ ] Visit homepage
  - [ ] Click "Member"
  - [ ] Register new member
  - [ ] Login with phone
  - [ ] View payment dashboard
  - [ ] See all 12 months displayed

- [ ] **Test Admin Features**
  - [ ] Go to homepage
  - [ ] Click "Admin"
  - [ ] Enter admin password
  - [ ] View all families
  - [ ] View family statistics
  - [ ] Click "Edit" on a member
  - [ ] Change payment status
  - [ ] Verify changes save

- [ ] **Test Mobile Responsiveness**
  - [ ] Open on phone/tablet
  - [ ] Test member registration
  - [ ] Verify buttons are clickable
  - [ ] Check spacing on small screens

- [ ] **Test Data Persistence**
  - [ ] Register a member
  - [ ] Wait 5 minutes
  - [ ] Clear browser cache
  - [ ] Login again
  - [ ] Verify data still exists

---

## Phase 5: Production Hardening (Optional but Recommended)

- [ ] **Change Admin Password**
  - [ ] Update in Vercel environment variables
  - [ ] Do NOT use default/example password
  - [ ] Use 12+ character password

- [ ] **Enable HTTPS**
  - Vercel does this automatically ✅

- [ ] **Set Up Domain (Optional)**
  - [ ] Buy custom domain (e.g., wecanpayments.com)
  - [ ] In Vercel: Settings → Domains
  - [ ] Add your domain
  - [ ] Update DNS settings

- [ ] **Enable Analytics (Optional)**
  - [ ] In Vercel: Analytics
  - [ ] Monitor usage and performance

- [ ] **Set Up Error Monitoring (Optional)**
  - [ ] Connect to Sentry.io
  - [ ] Get alerts for errors

---

## Phase 6: Ongoing Maintenance

- [ ] **Weekly**
  - [ ] Backup Supabase data (export in dashboard)
  - [ ] Check analytics for unusual activity

- [ ] **Monthly**
  - [ ] Review family payment statistics
  - [ ] Send payment reminders to members
  - [ ] Update member status as payments arrive

- [ ] **Quarterly**
  - [ ] Review user feedback
  - [ ] Plan new features
  - [ ] Update dependencies (`npm update`)

---

## Common Issues & Solutions

### Issue: "Build fails on Vercel"

**Check:**
1. Vercel build logs (shows specific error)
2. All environment variables are set
3. Supabase tables exist (run migration again)

**Solution:**
```bash
# Rebuild locally first
npm run build

# Check for errors
npm run lint
```

### Issue: "Cannot connect to Supabase from Vercel"

**Check:**
1. Supabase URL is correct (no extra spaces)
2. Supabase key is correct
3. Supabase project is active (not paused)

**Solution:**
- Copy credentials again directly from Supabase
- Re-paste in Vercel environment variables
- Redeploy

### Issue: "Admin login not working on live site"

**Check:**
1. Admin password in Vercel matches `.env.local`
2. Password doesn't have special characters issues
3. Browser cache cleared

**Solution:**
```bash
# Clear Vercel cache
# Settings → Git → Clear Cache → Redeploy
```

### Issue: "Member data not saving"

**Check:**
1. Supabase RLS policies enabled
2. Supabase project is active
3. Network tab in browser (check for errors)

**Solution:**
- Check Supabase SQL Editor
- Verify tables have data
- Check RLS policies are correct

---

## Rollback Plan

If something goes wrong in production:

1. **Immediate:**
   - Disable Vercel deployment (Settings → Git → Disable)
   - Tell users to use backup link
   - Investigate issue

2. **Rollback:**
   ```bash
   git revert HEAD
   git push
   ```

3. **Re-enable:**
   - Fix the issue
   - Push fix to GitHub
   - Vercel auto-deploys
   - Re-enable if needed

---

## Success Checklist

✅ All phases completed  
✅ Local testing passed  
✅ Git repository on GitHub  
✅ Vercel deployment successful  
✅ Live URL accessible  
✅ Member features working  
✅ Admin features working  
✅ Mobile responsive  
✅ Data persisting correctly  
✅ No console errors  

---

## Support Resources

**If you get stuck:**

1. **Supabase Issues:**
   - Docs: supabase.com/docs
   - Support: supabase.com/support

2. **Vercel Issues:**
   - Docs: vercel.com/docs
   - Community: vercel.com/community

3. **Next.js Issues:**
   - Docs: nextjs.org/docs
   - Discussions: github.com/vercel/next.js/discussions

4. **React Issues:**
   - Docs: react.dev
   - Community: stackoverflow.com (tag: reactjs)

---

## Final Notes

- **Total Setup Time:** ~40 minutes
- **Monthly Maintenance:** ~30 minutes
- **Cost:** $0 (free tier for all services)
- **Scalability:** Handles 1000+ users easily

---

🎉 **You're ready to go live!** 🎉

Remember to:
- Keep your admin password secure
- Backup important data regularly
- Monitor analytics for issues
- Update dependencies monthly

Good luck! 🚀
