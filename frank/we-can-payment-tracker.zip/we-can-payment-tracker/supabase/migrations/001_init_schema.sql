-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── Groups table ──────────────────────────────────────────
create table if not exists groups (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  created_at timestamp default now()
);

-- Seed the 10 groups (only if the table is empty)
insert into groups (name)
select * from (values
  ('Gentle Giants Family'),
  ('Kind Souls Family'),
  ('Little Lights Family'),
  ('Golden Hearts Family'),
  ('Faith Walkers Family'),
  ('Warriors Family'),
  ('Victorious Family'),
  ('Tigers Family'),
  ('Anointed Family'),
  ('Solidarity Family')
) as seed(name)
where not exists (select 1 from groups);

-- ── Members table ─────────────────────────────────────────
create table if not exists members (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  gender text not null,
  phone text not null,
  group_id uuid references groups(id) on delete cascade,
  registered_at timestamp default now(),
  updated_at timestamp default now()
);

-- One member per phone number (normalized digits)
create unique index if not exists members_phone_unique on members (phone);

-- Speed up "members in group" lookups
create index if not exists members_group_idx on members (group_id);

-- ── Payments table (one row per member per month per year) ─
create table if not exists payments (
  id uuid primary key default uuid_generate_v4(),
  member_id uuid references members(id) on delete cascade,
  month int not null,       -- 1 = January, 12 = December
  year int not null,
  status text not null default 'unpaid',  -- 'paid' | 'pending' | 'unpaid'
  amount int not null default 1000,  -- in RWF
  marked_at timestamp default now(),
  marked_by text,  -- admin identifier
  notes text
);

-- Only one payment record per member per month per year
create unique index if not exists payments_unique
  on payments (member_id, month, year);

-- Speed up per-member payment lookups
create index if not exists payments_member_idx on payments (member_id);

-- Speed up monthly reports
create index if not exists payments_month_year_idx on payments (month, year);

-- ── Row Level Security ────────────────────────────────────
alter table groups   enable row level security;
alter table members  enable row level security;
alter table payments enable row level security;

-- Drop old policies if re-running
drop policy if exists "groups read" on groups;
drop policy if exists "members read" on members;
drop policy if exists "members insert" on members;
drop policy if exists "payments read" on payments;
drop policy if exists "payments insert" on payments;
drop policy if exists "payments update" on payments;

-- groups: read-only (seeded once)
create policy "groups read" on groups for select using (true);

-- members: anyone can read and register
create policy "members read" on members for select using (true);
create policy "members insert" on members for insert with check (true);

-- payments: read all; insert + update by admin
create policy "payments read" on payments for select using (true);
create policy "payments insert" on payments for insert with check (true);
create policy "payments update" on payments for update using (true) with check (true);
