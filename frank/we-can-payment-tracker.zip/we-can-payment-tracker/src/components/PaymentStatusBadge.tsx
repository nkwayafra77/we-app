import { CheckCircle, Clock, XCircle } from 'lucide-react'

interface PaymentStatusBadgeProps {
  status: 'paid' | 'pending' | 'unpaid'
  size?: 'sm' | 'md' | 'lg'
}

export default function PaymentStatusBadge({ 
  status, 
  size = 'md' 
}: PaymentStatusBadgeProps) {
  const configs = {
    paid: {
      bg: 'bg-green-100',
      text: 'text-green-800',
      label: 'Paid',
      icon: CheckCircle,
    },
    pending: {
      bg: 'bg-yellow-100',
      text: 'text-yellow-800',
      label: 'Pending',
      icon: Clock,
    },
    unpaid: {
      bg: 'bg-red-100',
      text: 'text-red-800',
      label: 'Not Paid',
      icon: XCircle,
    },
  }

  const config = configs[status]
  const Icon = config.icon

  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-2 text-sm',
    lg: 'px-4 py-3 text-base',
  }

  return (
    <div className={`inline-flex items-center space-x-1.5 rounded-full ${config.bg} ${config.text} ${sizeClasses[size]} font-medium`}>
      <Icon className={size === 'sm' ? 'w-3 h-3' : size === 'md' ? 'w-4 h-4' : 'w-5 h-5'} />
      <span>{config.label}</span>
    </div>
  )
}
