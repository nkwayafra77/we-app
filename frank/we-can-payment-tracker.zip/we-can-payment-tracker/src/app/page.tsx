'use client'

import Link from 'next/link'
import { Users, Lock } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-2">
            We Can
          </h1>
          <p className="text-blue-100 text-lg">
            Payment Tracker
          </p>
          <p className="text-blue-200 text-sm mt-2">
            Track family group contributions
          </p>
        </div>

        {/* Options */}
        <div className="space-y-4">
          {/* User Option */}
          <Link
            href="/user/login"
            className="block"
          >
            <div className="card hover:shadow-xl transition-shadow cursor-pointer border-2 border-transparent hover:border-blue-500">
              <div className="flex items-center space-x-4">
                <div className="bg-green-100 p-4 rounded-lg">
                  <Users className="w-8 h-8 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 text-lg">Member</h3>
                  <p className="text-gray-600 text-sm">View your payment status</p>
                </div>
              </div>
            </div>
          </Link>

          {/* Admin Option */}
          <Link
            href="/admin/login"
            className="block"
          >
            <div className="card hover:shadow-xl transition-shadow cursor-pointer border-2 border-transparent hover:border-blue-500">
              <div className="flex items-center space-x-4">
                <div className="bg-purple-100 p-4 rounded-lg">
                  <Lock className="w-8 h-8 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 text-lg">Admin</h3>
                  <p className="text-gray-600 text-sm">Manage all payments</p>
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <p className="text-blue-200 text-xs">
            © 2024 We Can Payment Tracker. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
}
