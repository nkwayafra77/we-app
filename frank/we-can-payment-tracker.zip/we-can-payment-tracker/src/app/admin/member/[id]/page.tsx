'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { fetchMemberByPhone, fetchMemberPayments, updatePaymentStatus, deleteMember, upsertPayment, Member, Payment, supabase } from '@/lib/supabaseClient'
import { ArrowLeft, Trash2, CheckCircle, Clock, XCircle } from 'lucide-react'
import PaymentStatusBadge from '@/components/PaymentStatusBadge'

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
]

const CURRENT_YEAR = new Date().getFullYear()

export default function AdminMemberPage() {
  const router = useRouter()
  const params = useParams()
  const memberId = params.id as string

  const [member, setMember] = useState<Member | null>(null)
  const [payments, setPayments] = useState<Payment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isUpdating, setIsUpdating] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [selectedYear, setSelectedYear] = useState(CURRENT_YEAR)

  useEffect(() => {
    // Check admin session
    if (typeof window !== 'undefined') {
      const adminSession = localStorage.getItem('adminSession')
      if (!adminSession) {
        router.push('/admin/login')
        return
      }
    }

    loadMemberData()
  }, [memberId])

  const loadMemberData = async () => {
    try {
      // Fetch member directly from Supabase
      const { data, error: err } = await supabase
        .from('members')
        .select('*')
        .eq('id', memberId)
        .single()

      if (err) throw err

      setMember(data as Member)

      // Fetch payments
      const paymentsData = await fetchMemberPayments(memberId)
      setPayments(paymentsData)
    } catch (err) {
      setError('Failed to load member data.')
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  const handlePaymentStatusChange = async (month: number, newStatus: 'paid' | 'pending' | 'unpaid') => {
    if (!member) return

    setIsUpdating(true)
    setError('')
    setSuccess('')

    try {
      await upsertPayment(memberId, month, selectedYear, newStatus)
      
      // Reload payments
      const updatedPayments = await fetchMemberPayments(memberId)
      setPayments(updatedPayments)
      
      setSuccess(`Payment status updated to ${newStatus}`)
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) {
      setError('Failed to update payment status.')
      console.error(err)
    } finally {
      setIsUpdating(false)
    }
  }

  const handleDeleteMember = async () => {
    if (!member) return

    const confirmed = window.confirm(
      `Are you sure you want to delete ${member.name}? This action cannot be undone.`
    )

    if (!confirmed) return

    setIsUpdating(true)
    setError('')

    try {
      await deleteMember(memberId)
      router.push('/admin/dashboard')
    } catch (err) {
      setError('Failed to delete member.')
      console.error(err)
      setIsUpdating(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  if (!member) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
          <button
            onClick={() => router.push('/admin/dashboard')}
            className="inline-flex items-center text-purple-600 hover:text-purple-800 mb-8"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </button>
          <div className="card text-center">
            <p className="text-red-600">Member not found.</p>
          </div>
        </div>
      </div>
    )
  }

  const yearPayments = payments.filter((p) => p.year === selectedYear)
  const paymentMap = new Map(yearPayments.map((p) => (p.month, p)))

  const years = Array.from(
    new Set([CURRENT_YEAR, ...payments.map((p) => p.year)])
  ).sort((a, b) => b - a)

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-4 py-6 sm:px-6">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => router.push('/admin/dashboard')}
            className="inline-flex items-center text-purple-100 hover:text-white mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold">{member.name}</h1>
          <p className="text-purple-100 text-sm mt-1">📱 {member.phone}</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 mt-8">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-600 text-sm">{success}</p>
          </div>
        )}

        {/* Member Info */}
        <div className="card mb-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            <div>
              <p className="text-gray-600 text-sm mb-1">Gender</p>
              <p className="text-lg font-semibold text-gray-900">{member.gender}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm mb-1">Registered</p>
              <p className="text-lg font-semibold text-gray-900">
                {new Date(member.registered_at).toLocaleDateString()}
              </p>
            </div>
            <div>
              <p className="text-gray-600 text-sm mb-1">Payment Status</p>
              <p className="text-lg font-semibold text-gray-900">
                {payments.filter((p) => p.status === 'paid').length} /{' '}
                {payments.length}
              </p>
            </div>
            <div>
              <p className="text-gray-600 text-sm mb-1">Amount</p>
              <p className="text-lg font-semibold text-gray-900">1,000 RWF</p>
            </div>
          </div>
        </div>

        {/* Payment Management */}
        <div className="card mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-gray-900">Payment History</h2>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="input max-w-xs"
              disabled={isUpdating}
            >
              {years.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {MONTHS.map((month, index) => {
              const monthNum = index + 1
              const payment = paymentMap.get(monthNum)
              const status = payment?.status || 'unpaid'

              return (
                <div
                  key={monthNum}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="font-semibold text-gray-900">{month}</p>
                      <p className="text-sm text-gray-600">{selectedYear}</p>
                    </div>
                    <PaymentStatusBadge status={status} size="sm" />
                  </div>

                  <div className="space-y-2">
                    <button
                      onClick={() => handlePaymentStatusChange(monthNum, 'paid')}
                      disabled={isUpdating}
                      className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-1 ${
                        status === 'paid'
                          ? 'bg-green-100 text-green-800 border-2 border-green-500'
                          : 'bg-gray-100 text-gray-600 hover:bg-green-50 border border-gray-300'
                      }`}
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Paid</span>
                    </button>
                    <button
                      onClick={() => handlePaymentStatusChange(monthNum, 'pending')}
                      disabled={isUpdating}
                      className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-1 ${
                        status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800 border-2 border-yellow-500'
                          : 'bg-gray-100 text-gray-600 hover:bg-yellow-50 border border-gray-300'
                      }`}
                    >
                      <Clock className="w-4 h-4" />
                      <span>Pending</span>
                    </button>
                    <button
                      onClick={() => handlePaymentStatusChange(monthNum, 'unpaid')}
                      disabled={isUpdating}
                      className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-1 ${
                        status === 'unpaid'
                          ? 'bg-red-100 text-red-800 border-2 border-red-500'
                          : 'bg-gray-100 text-gray-600 hover:bg-red-50 border border-gray-300'
                      }`}
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Not Paid</span>
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Delete Member */}
        <div className="card border-red-200 bg-red-50">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-red-900 mb-1">Delete Member</h3>
              <p className="text-red-700 text-sm">
                This action cannot be undone. All payment records will be deleted.
              </p>
            </div>
            <button
              onClick={handleDeleteMember}
              disabled={isUpdating}
              className="btn-danger flex items-center space-x-2 disabled:opacity-50"
            >
              <Trash2 className="w-5 h-5" />
              <span>Delete</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
