'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { fetchGroups, fetchMembersWithGroup, fetchAllPayments, Group, Payment } from '@/lib/supabaseClient'
import { LogOut, AlertCircle, BarChart3 } from 'lucide-react'
import PaymentStatusBadge from '@/components/PaymentStatusBadge'

const CURRENT_MONTH = new Date().getMonth() + 1
const CURRENT_YEAR = new Date().getFullYear()

export default function AdminDashboard() {
  const router = useRouter()
  const [groups, setGroups] = useState<Group[]>([])
  const [selectedGroupId, setSelectedGroupId] = useState<string>('')
  const [payments, setPayments] = useState<Payment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')
  const [membersData, setMembersData] = useState<any[]>([])

  useEffect(() => {
    // Check admin session
    if (typeof window !== 'undefined') {
      const adminSession = localStorage.getItem('adminSession')
      if (!adminSession) {
        router.push('/admin/login')
        return
      }
    }

    const loadData = async () => {
      try {
        const groupsData = await fetchGroups()
        setGroups(groupsData)
        
        if (groupsData.length > 0) {
          setSelectedGroupId(groupsData[0].id)
        }

        const paymentsData = await fetchAllPayments(CURRENT_MONTH, CURRENT_YEAR)
        setPayments(paymentsData)
      } catch (err) {
        setError('Failed to load data. Please try again.')
        console.error(err)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [router])

  // Load members when group changes
  useEffect(() => {
    if (selectedGroupId) {
      loadGroupMembers()
    }
  }, [selectedGroupId])

  const loadGroupMembers = async () => {
    try {
      const members = await fetchMembersWithGroup(selectedGroupId)
      setMembersData(members)
    } catch (err) {
      setError('Failed to load group members.')
      console.error(err)
    }
  }

  const handleLogout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('adminSession')
      localStorage.removeItem('adminLoginTime')
    }
    router.push('/admin/login')
  }

  const getGroupStats = (groupId: string) => {
    const groupPayments = payments.filter((p) => {
      const member = membersData.find((m) => m.id === p.member_id)
      return member?.group_id === groupId
    })

    return {
      total: groupPayments.length,
      paid: groupPayments.filter((p) => p.status === 'paid').length,
      pending: groupPayments.filter((p) => p.status === 'pending').length,
      unpaid: groupPayments.filter((p) => p.status === 'unpaid').length,
    }
  }

  const getCurrentGroupMembers = () => {
    return membersData.filter((m) => m.group_id === selectedGroupId)
  }

  const getCurrentGroupStats = getGroupStats(selectedGroupId)

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-4 py-6 sm:px-6">
        <div className="max-w-7xl mx-auto flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
              <BarChart3 className="w-8 h-8" />
              <span>Admin Dashboard</span>
            </h1>
            <p className="text-purple-100">
              Manage payments for {CURRENT_MONTH}/{CURRENT_YEAR}
            </p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 bg-purple-500 hover:bg-purple-400 px-4 py-2 rounded-lg text-white transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 mt-8">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-600">{error}</p>
          </div>
        )}

        {/* Group Selector and Overall Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Group Selector */}
          <div className="lg:col-span-1">
            <div className="card">
              <h2 className="font-semibold text-gray-900 mb-4">Select Family</h2>
              <select
                value={selectedGroupId}
                onChange={(e) => setSelectedGroupId(e.target.value)}
                className="input"
              >
                {groups.map((group) => (
                  <option key={group.id} value={group.id}>
                    {group.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Statistics */}
          <div className="card lg:col-span-3">
            <h2 className="font-semibold text-gray-900 mb-4">Payment Statistics</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <p className="text-gray-600 text-sm mb-1">Total Members</p>
                <p className="text-3xl font-bold text-gray-900">{getCurrentGroupMembers().length}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm mb-1">Paid</p>
                <p className="text-3xl font-bold text-green-600">{getCurrentGroupStats.paid}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm mb-1">Pending</p>
                <p className="text-3xl font-bold text-yellow-600">{getCurrentGroupStats.pending}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm mb-1">Not Paid</p>
                <p className="text-3xl font-bold text-red-600">{getCurrentGroupStats.unpaid}</p>
              </div>
            </div>
          </div>
        </div>

        {/* All Families Summary */}
        <div className="card mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">All Families Overview</h2>
          
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Family Name</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Members</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900">Paid</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900">Pending</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900">Not Paid</th>
                  <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900">Progress</th>
                </tr>
              </thead>
              <tbody>
                {groups.map((group) => {
                  const stats = getGroupStats(group.id)
                  const progress = stats.total > 0 ? (stats.paid / stats.total) * 100 : 0
                  
                  return (
                    <tr key={group.id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{group.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{stats.total}</td>
                      <td className="px-6 py-4 text-center">
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-green-100 text-green-800 font-semibold text-sm">
                          {stats.paid}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-yellow-100 text-yellow-800 font-semibold text-sm">
                          {stats.pending}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-red-100 text-red-800 font-semibold text-sm">
                          {stats.unpaid}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-green-500 h-2 rounded-full transition-all"
                              style={{ width: `${progress}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium text-gray-600 w-8">
                            {Math.round(progress)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Members Management */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-6">
            Members - {groups.find((g) => g.id === selectedGroupId)?.name}
          </h2>

          {getCurrentGroupMembers().length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600">No members in this family yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Phone</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Gender</th>
                    <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900">Status</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Registered</th>
                    <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {getCurrentGroupMembers().map((member) => {
                    const memberPayment = payments.find(
                      (p) =>
                        p.member_id === member.id &&
                        p.month === CURRENT_MONTH &&
                        p.year === CURRENT_YEAR
                    )
                    const status = memberPayment?.status || 'unpaid'

                    return (
                      <tr key={member.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-medium text-gray-900">{member.name}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{member.phone}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{member.gender}</td>
                        <td className="px-6 py-4 text-center">
                          <PaymentStatusBadge status={status} size="sm" />
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {new Date(member.registered_at).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => router.push(`/admin/member/${member.id}`)}
                            className="text-blue-600 hover:text-blue-800 font-medium text-sm"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
