'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { fetchMemberByPhone, savePhoneSession } from '@/lib/supabaseClient'
import { ArrowLeft, Phone } from 'lucide-react'

export default function UserLogin() {
  const router = useRouter()
  const [phone, setPhone] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      const normalizedPhone = phone.replace(/\D/g, '')
      
      if (normalizedPhone.length < 10) {
        setError('Please enter a valid phone number')
        setIsLoading(false)
        return
      }

      const member = await fetchMemberByPhone(normalizedPhone)
      
      if (!member) {
        // Redirect to registration
        savePhoneSession(normalizedPhone)
        router.push('/user/register')
        return
      }

      // Member exists, save session and redirect to dashboard
      savePhoneSession(normalizedPhone)
      router.push('/user/dashboard')
    } catch (err: any) {
      setError('Error connecting to server. Please try again.')
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  const formatPhoneInput = (value: string) => {
    const digits = value.replace(/\D/g, '')
    return digits
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <Link
          href="/"
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Link>

        {/* Card */}
        <div className="card">
          <div className="text-center mb-8">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Member Login
            </h1>
            <p className="text-gray-600">
              Enter your phone number to access your payment status
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}

            <div>
              <label className="label">Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(formatPhoneInput(e.target.value))}
                placeholder="0788123456"
                className="input"
                disabled={isLoading}
              />
              <p className="text-xs text-gray-500 mt-2">
                Format: 10 digits (e.g., 0788123456)
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading || phone.length < 10}
              className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Checking...' : 'Continue'}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-600">
            <p>
              Don't have an account?{' '}
              <Link
                href="/user/register"
                className="text-blue-600 font-medium hover:text-blue-800"
              >
                Register here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
