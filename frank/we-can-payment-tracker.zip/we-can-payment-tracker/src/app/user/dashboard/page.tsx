'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { getPhoneSession, clearPhoneSession, fetchMemberByPhone, fetchMemberPayments, Member, Payment } from '@/lib/supabaseClient'
import { LogOut, AlertCircle } from 'lucide-react'
import PaymentStatusBadge from '@/components/PaymentStatusBadge'

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
]

const CURRENT_YEAR = new Date().getFullYear()
const CURRENT_MONTH = new Date().getMonth() + 1

export default function UserDashboard() {
  const router = useRouter()
  const [member, setMember] = useState<Member | null>(null)
  const [payments, setPayments] = useState<Payment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const loadData = async () => {
      try {
        const phone = getPhoneSession()
        if (!phone) {
          router.push('/user/login')
          return
        }

        const memberData = await fetchMemberByPhone(phone)
        if (!memberData) {
          clearPhoneSession()
          router.push('/user/login')
          return
        }

        setMember(memberData)

        const paymentsData = await fetchMemberPayments(memberData.id)
        setPayments(paymentsData)
      } catch (err) {
        setError('Failed to load data. Please try again.')
        console.error(err)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [router])

  const handleLogout = () => {
    clearPhoneSession()
    router.push('/user/login')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!member) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="card max-w-md">
          <p className="text-red-600">Session expired. Please log in again.</p>
          <button
            onClick={handleLogout}
            className="btn-primary w-full mt-4"
          >
            Go to Login
          </button>
        </div>
      </div>
    )
  }

  // Prepare payment data
  const paymentMap = new Map(
    payments.map((p) => (`${p.year}-${p.month}`, p))
  )

  // Generate last 12 months
  const monthsToShow = []
  for (let i = 0; i < 12; i++) {
    let month = CURRENT_MONTH - i
    let year = CURRENT_YEAR
    
    if (month < 1) {
      month += 12
      year -= 1
    }
    
    monthsToShow.push({ month, year })
  }

  const paidCount = payments.filter(p => p.status === 'paid').length
  const pendingCount = payments.filter(p => p.status === 'pending').length
  const unpaidCount = payments.filter(p => p.status === 'unpaid').length

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white px-4 py-6 sm:px-6">
        <div className="max-w-6xl mx-auto flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome, {member.name}</h1>
            <div className="space-y-1 text-blue-100 text-sm">
              <p>📱 {member.phone}</p>
              <p>👨‍👩‍👧 {member.gender}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-400 px-4 py-2 rounded-lg text-white transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 mt-8">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-600">{error}</p>
          </div>
        )}

        {/* Statistics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Paid</p>
                <p className="text-3xl font-bold text-green-600">{paidCount}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <div className="w-8 h-8 bg-green-500 rounded-full"></div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Pending</p>
                <p className="text-3xl font-bold text-yellow-600">{pendingCount}</p>
              </div>
              <div className="bg-yellow-100 p-3 rounded-lg">
                <div className="w-8 h-8 bg-yellow-500 rounded-full"></div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Not Paid</p>
                <p className="text-3xl font-bold text-red-600">{unpaidCount}</p>
              </div>
              <div className="bg-red-100 p-3 rounded-lg">
                <div className="w-8 h-8 bg-red-500 rounded-full"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Payment History */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Payment Status History</h2>
          
          <div className="overflow-x-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {monthsToShow.map(({ month, year }) => {
                const key = `${year}-${month}`
                const payment = paymentMap.get(key)
                const status = payment?.status || 'unpaid'
                
                return (
                  <div key={key} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="font-semibold text-gray-900">
                          {MONTHS[month - 1]}
                        </p>
                        <p className="text-sm text-gray-600">{year}</p>
                      </div>
                      <PaymentStatusBadge status={status} />
                    </div>
                    
                    <div className="pt-3 border-t border-gray-200">
                      <p className="text-sm text-gray-600">
                        Amount: <span className="font-semibold text-gray-900">1,000 RWF</span>
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Info Message */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-blue-800 text-sm">
            ℹ️ You can see your payment status here. Contact your family leader or admin to make a payment or update your status.
          </p>
        </div>
      </div>
    </div>
  )
}
