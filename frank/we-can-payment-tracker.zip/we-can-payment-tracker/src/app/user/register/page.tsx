'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { fetchGroups, registerMember, getPhoneSession, savePhoneSession } from '@/lib/supabaseClient'
import { ArrowLeft, UserPlus } from 'lucide-react'

interface Group {
  id: string
  name: string
}

export default function UserRegister() {
  const router = useRouter()
  const [groups, setGroups] = useState<Group[]>([])
  const [formData, setFormData] = useState({
    name: '',
    gender: '',
    phone: '',
    groupId: '',
  })
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingGroups, setIsLoadingGroups] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const loadGroups = async () => {
      try {
        const data = await fetchGroups()
        setGroups(data)
      } catch (err) {
        setError('Failed to load families. Please try again.')
        console.error(err)
      } finally {
        setIsLoadingGroups(false)
      }
    }

    // Get phone from session if available
    const sessionPhone = getPhoneSession()
    if (sessionPhone) {
      setFormData((prev) => ({ ...prev, phone: sessionPhone }))
    }

    loadGroups()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      if (!formData.name || !formData.gender || !formData.groupId) {
        setError('Please fill in all fields')
        setIsLoading(false)
        return
      }

      const normalizedPhone = formData.phone.replace(/\D/g, '')
      
      const member = await registerMember(
        formData.name,
        formData.gender,
        normalizedPhone,
        formData.groupId
      )

      // Save phone and redirect
      savePhoneSession(normalizedPhone)
      router.push('/user/dashboard')
    } catch (err: any) {
      if (err.code === '23505') {
        setError('This phone number is already registered')
      } else {
        setError('Registration failed. Please try again.')
      }
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <Link
          href="/user/login"
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Link>

        {/* Card */}
        <div className="card">
          <div className="text-center mb-8">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <UserPlus className="w-8 h-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Register
            </h1>
            <p className="text-gray-600">
              Join a family group and start tracking payments
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}

            {/* Full Name */}
            <div>
              <label className="label">Full Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your full name"
                className="input"
                disabled={isLoading}
              />
            </div>

            {/* Gender */}
            <div>
              <label className="label">Gender</label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="input"
                disabled={isLoading}
              >
                <option value="">Select gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>

            {/* Phone */}
            <div>
              <label className="label">Phone Number</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="0788123456"
                className="input"
                disabled={isLoading || !!getPhoneSession()}
              />
            </div>

            {/* Family Group */}
            <div>
              <label className="label">Select Your Family</label>
              {isLoadingGroups ? (
                <div className="flex justify-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <select
                  name="groupId"
                  value={formData.groupId}
                  onChange={handleChange}
                  className="input"
                  disabled={isLoading}
                >
                  <option value="">Choose a family</option>
                  {groups.map((group) => (
                    <option key={group.id} value={group.id}>
                      {group.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <button
              type="submit"
              disabled={isLoading || isLoadingGroups || !formData.name || !formData.gender || !formData.groupId}
              className="btn-success w-full disabled:opacity-50 disabled:cursor-not-allowed font-medium"
            >
              {isLoading ? 'Registering...' : 'Complete Registration'}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-600">
            <p>
              Already have an account?{' '}
              <Link
                href="/user/login"
                className="text-blue-600 font-medium hover:text-blue-800"
              >
                Log in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
