import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// ── Types ────────────────────────────────────────────────
export interface Group {
  id: string
  name: string
  created_at: string
}

export interface Member {
  id: string
  name: string
  gender: string
  phone: string
  group_id: string
  registered_at: string
}

export interface Payment {
  id: string
  member_id: string
  month: number
  year: number
  status: 'paid' | 'pending' | 'unpaid'
  amount: number
  marked_at: string
  marked_by?: string
  notes?: string
}

// ── Auth Helpers ─────────────────────────────────────────
export const savePhoneSession = (phone: string) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('userPhone', phone)
  }
}

export const getPhoneSession = (): string | null => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('userPhone')
  }
  return null
}

export const clearPhoneSession = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('userPhone')
  }
}

// ── Database Queries ────────────────────────────────────
export const fetchGroups = async () => {
  const { data, error } = await supabase
    .from('groups')
    .select('*')
    .order('name')
  
  if (error) throw error
  return data as Group[]
}

export const fetchMemberByPhone = async (phone: string) => {
  const { data, error } = await supabase
    .from('members')
    .select('*')
    .eq('phone', phone.replace(/\D/g, ''))
    .single()
  
  if (error && error.code !== 'PGRST116') throw error
  return data as Member | null
}

export const registerMember = async (
  name: string,
  gender: string,
  phone: string,
  groupId: string
) => {
  const normalizedPhone = phone.replace(/\D/g, '')
  
  const { data, error } = await supabase
    .from('members')
    .insert({
      name,
      gender,
      phone: normalizedPhone,
      group_id: groupId,
    })
    .select()
    .single()
  
  if (error) throw error
  return data as Member
}

export const fetchMemberPayments = async (memberId: string) => {
  const { data, error } = await supabase
    .from('payments')
    .select('*')
    .eq('member_id', memberId)
    .order('year', { ascending: false })
    .order('month', { ascending: false })
  
  if (error) throw error
  return data as Payment[]
}

export const fetchAllPayments = async (month?: number, year?: number) => {
  let query = supabase.from('payments').select('*')
  
  if (month) query = query.eq('month', month)
  if (year) query = query.eq('year', year)
  
  const { data, error } = await query.order('year', { ascending: false })
  
  if (error) throw error
  return data as Payment[]
}

export const fetchMembersWithGroup = async (groupId?: string) => {
  let query = supabase
    .from('members')
    .select('*, groups(name)')
  
  if (groupId) query = query.eq('group_id', groupId)
  
  const { data, error } = await query.order('registered_at', { ascending: false })
  
  if (error) throw error
  return data
}

export const updatePaymentStatus = async (
  paymentId: string,
  status: 'paid' | 'pending' | 'unpaid',
  notes?: string
) => {
  const { data, error } = await supabase
    .from('payments')
    .update({
      status,
      marked_at: new Date().toISOString(),
      notes,
    })
    .eq('id', paymentId)
    .select()
    .single()
  
  if (error) throw error
  return data as Payment
}

export const deleteMember = async (memberId: string) => {
  const { error } = await supabase
    .from('members')
    .delete()
    .eq('id', memberId)
  
  if (error) throw error
}

export const upsertPayment = async (
  memberId: string,
  month: number,
  year: number,
  status: 'paid' | 'pending' | 'unpaid'
) => {
  const { data, error } = await supabase
    .from('payments')
    .upsert({
      member_id: memberId,
      month,
      year,
      status,
      amount: 1000,
      marked_at: new Date().toISOString(),
    }, {
      onConflict: 'member_id,month,year',
    })
    .select()
    .single()
  
  if (error) throw error
  return data as Payment
}
