# 🚀 Quick Start Guide - We Can Payment Tracker

Get up and running in **15 minutes**!

## Step 1: Install Node.js (5 min)

1. Go to [nodejs.org](https://nodejs.org)
2. Download the **LTS version**
3. Install it (click Next → Install → Finish)
4. Verify installation:
   ```bash
   node --version
   npm --version
   ```

## Step 2: Set Up Supabase (5 min)

1. Go to [supabase.com](https://supabase.com)
2. Sign up with your email
3. Create a new project:
   - Project name: "We Can Payment Tracker"
   - Password: Create a strong password
   - Region: Choose closest to you
   - Click "Create new project" and wait 2-3 minutes

4. Once ready, go to **Settings → API**
5. Copy and save:
   - `Project URL` 
   - `anon public key`

## Step 3: Create Tables (3 min)

1. In Supabase, click **SQL Editor** (left sidebar)
2. Click **New Query**
3. Open the file: `supabase/migrations/001_init_schema.sql`
4. Copy ALL the code
5. Paste into the Supabase SQL editor
6. Click **Run** (▶️)
7. Wait for green checkmarks ✅

## Step 4: Configure the App (1 min)

1. In the project folder, create `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=paste-your-project-url-here
   NEXT_PUBLIC_SUPABASE_ANON_KEY=paste-your-anon-key-here
   NEXT_PUBLIC_ADMIN_PASSWORD=your-admin-password
   ```

2. Replace the values with your Supabase credentials

## Step 5: Run the App (1 min)

1. Open terminal/command prompt
2. Go to project folder:
   ```bash
   cd we-can-payment-tracker
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Start the app:
   ```bash
   npm run dev
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## 🎉 You're Done!

The app is now running locally!

### Test It Out

**As a Member:**
- Click "Member" → "Register here"
- Fill in form with test data
- View your payment dashboard

**As Admin:**
- Click "Admin"
- Enter your admin password
- See all families and members

---

## Next Steps: Deploy to Vercel

Once working locally, deploy online in **2 minutes**:

1. Push to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/your-username/repo-name.git
   git push -u origin main
   ```

2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repo
5. Add environment variables (same as `.env.local`)
6. Click "Deploy"
7. Done! Your app is live! 🎊

---

## Common Issues

**"Cannot find node"**
- Restart command prompt after installing Node.js

**"Port 3000 in use"**
- Run: `npm run dev -- -p 3001` (use port 3001)

**"Supabase connection error"**
- Check environment variables in `.env.local`
- Verify Supabase project is active

**"Admin login fails"**
- Verify password in `.env.local` matches what you entered
- Restart dev server: `npm run dev`

---

## Need More Help?

Read the full **README.md** for detailed documentation.

Happy tracking! 🎯
